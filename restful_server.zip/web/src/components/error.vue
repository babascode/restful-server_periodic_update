<template>
    <div>
        错误
    </div>
</template>
<script>

export default {
    name: 'Error'
}
</script>