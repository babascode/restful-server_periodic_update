#!/bin/bash

mkdir -p ../workspace/web
cp -r dist/* ../workspace/web