#!/bin/bash

export PATH=$PATH:node-v12.4.0-linux-x64/bin

npm run dev